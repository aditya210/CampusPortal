$(document).ready(function() 
{
  $('#mainav').localScroll({duration:800});
}
);
