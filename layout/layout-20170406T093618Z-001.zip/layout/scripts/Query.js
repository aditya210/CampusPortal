alert('Thank you for your query. Our Team will contact you as soon as possible');
window.location.href='home.php?success';
   